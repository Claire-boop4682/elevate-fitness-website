/*
	Escape Velocity by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
*/

(function($) {

	var	$window = $(window),
		$body = $('body');

	// Breakpoints.
		breakpoints({
			xlarge:  [ '1281px',  '1680px' ],
			large:   [ '981px',   '1280px' ],
			medium:  [ '737px',   '980px'  ],
			small:   [ null,      '736px'  ]
		});

	// Play initial animations on page load.
		$window.on('load', function() {
			window.setTimeout(function() {
				$body.removeClass('is-preload');
			}, 100);
		});

	// Dropdowns.
		$('#nav > ul').dropotron({
			mode: 'fade',
			noOpenerFade: true,
			alignment: 'center',
			detach: false
		});

	// Nav.

		// Title Bar.
			$(
				'<div id="titleBar">' +
					'<a href="#navPanel" class="toggle"></a>' +
					'<span class="title">' + $('#logo h1').html() + '</span>' +
				'</div>'
			)
				.appendTo($body);

		// Panel.
			$(
				'<div id="navPanel">' +
					'<nav>' +
						$('#nav').navList() +
					'</nav>' +
				'</div>'
			)
				.appendTo($body)
				.panel({
					delay: 500,
					hideOnClick: true,
					hideOnSwipe: true,
					resetScroll: true,
					resetForms: true,
					side: 'left',
					target: $body,
					visibleClass: 'navPanel-visible'
				});

	// Mouse Cursor. 
	// Glowing mouse cursor in jQuery, 
	$(document).mousemove(function(event) {
		let mouseX = event.clientX - 15; 
		let mouseY = event.clientY - 15; 
			
		$('.cursor-glow').css({
			left: mouseX + 'px',
			top: mouseY + 'px'
		})
	})

	// Gym Services. 
	// Interactive flip cards in jQuery (Moreira, 2020)
	$('.card').on({
		mouseenter: function() {
			$(this).css('transform', 'rotateY(180deg)');
		}, 
		mouseleave: function() {
			$(this).css('transform', 'rotateY(0deg)');
		}
	})

	// Booking.
	$('.book').on({
		mouseenter: function() {
			$(this).css('backgroundColor', 'grey');
		}, 
		mouseleave: function() {
			$(this).css('backgroundColor', 'black')
		}
	})


	// Filtering classes.
	// Reference: www.w3schools.com/howto/howto_js_filter_elements.asp (Adapted into jQuery)
	$(document).ready(function() {
		$(".dropdown-content a").click(function(event) {
			event.preventDefault();
			const filter = $(this).text().trim().toUpperCase();

			$(".bookings .class").each(function() {
				const title = $(this).find("h1").text().trim().toUpperCase();
				const matches = (filter === "ALL" || title.includes(filter));

				if (matches) {
					$(this).css({
						visibility: 'visible', 
						opacity: '1',
						position: 'relative',
         				pointerEvents: 'auto'
					})
				} else {
					$(this).css({
						visibility: 'hidden', 
						opacity: '0',
						position: 'absolute',
         				pointerEvents: 'none'
					})
				}
			})
		})
	})

	// More Info.
	$('.button.style2').on({
		mouseenter: function() {
			$(this).css('backgroundColor', 'grey')
		}, 
		mouseleave: function() {
			$(this).css('backgroundColor', '#003344');
		}
	})

	// Booking Form.
	$('.book').click(function() {
		$('.bookingConfirmation').fadeIn(); 
	})

	$('.close').click(function() {
		$('.bookingConfirmation').fadeOut(); 
	})

	$(window).click(function(event) {
		if ($(event.target).is('.bookingConfirmation')) {
			$('.bookingConfirmation').fadeOut();
		}
	})

})(jQuery);